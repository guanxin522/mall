/*
* @Author: xin
* @Date:   2018-04-26 20:02:29
* @Last Modified by:   xin
* @Last Modified time: 2018-04-29 11:12:48
*/
require('./layout.css');
require('node_modules/font-awesome/css/font-awesome.min.css');
require('./footer/index.css');